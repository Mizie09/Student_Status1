<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
</head>
<body>
    <div>
        <ul>
            <li><a href="<?= site_url('dashboard') ?>">Dashboard</a></li>
            <li><a href="<?= site_url('Employees')?>">Employees</a></li>
        </ul>
    </div>
    <div>
        <div>
            <h3>Dashboard</h3>
        </div>
        <div>
            <table border>
                <tr>
                    <th>Student ID</th>
                    <th>Student Name</th>
                    <th>Strand</th>
                    <th>Grade</th>
                    <th>Section</th>
                    <th>Status</th>
                    <th>Absences</th>
                </tr>
            </table>
        </div>
    </div>

    
</body>
</html>