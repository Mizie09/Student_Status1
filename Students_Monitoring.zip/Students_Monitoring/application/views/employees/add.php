<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employees</title>
</head>

<body>
    <div>
        <ul>
            <li><a href="<?= site_url('dashboard') ?>">Dashboard</a></li>
            <li><a href="<?= site_url('Employees') ?>">Employees</a></li>
        </ul>
    </div>
    <div>
        <div>
            <h3>Employees</h3>
        </div>
        <div>
            <form action="<?= site_url('Employees/add')?>" method="post">
                    
                    <?php
                    if (validation_errors())
                    {
                            echo validation_errors();
                    }
                    ?>
                    <label for="">Employee No.</label><input name="users_id" type="text"><br>
            <label for="">Last name</label><input name="last_name" type="text"><br>
            <label for="">First name</label><input name="first_name" type="text"><br>
            <label for="">Middle Name</label><input name="middle_name" type="text"><br>
            <label for="">Birthday</label><input name="birthday" type="date" name="" id=""><br>
            <label for="">Age</label><input name="age" type="number" name="" id=""><br>
            <label for="">Email</label><input name="email" type="email" name="" id=""><br>
            <label for="">Department</label>
            <select name="department" >
                <option value="">Choose</option>
                <option value="IT">IT</option>
                <option value="Finance">Finance</option>
            </select><br>

            <input type="submit" value="Submit" >


            </form>
        </div>
        
    </div>


</body>

</html>