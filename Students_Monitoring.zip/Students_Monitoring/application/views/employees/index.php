<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employees</title>
</head>
<body>
    <div>
        <ul>
            <li><a href="<?= site_url('dashboard') ?>">Dashboard</a></li>
            <li><a href="<?= site_url('Employees')?>">Employees</a></li>
        </ul>
    </div>
    <div>
        <div>
            <h3>Employees</h3>
        </div>
        <div>
            <label>Search: 
            </label><input type="search" name="" id="">
            <a href="<?= site_url('Employees/add') ?>">Add</a>
        </div>
        <div>
            <?php
                if($this->session->flashdata('msg')){
                    echo $this->session->flashdata('msg');
                }

            ?>
            <table border>
<thead>
                <tr>
                    <th>Employee No.</th>
                    <th>Last Name</th>
                    <th>First Name</th>
                    <th>Middle Name</th>
                    <th>Age</th>
                    <th>Email</th>
                    <th>Department</th>
                    <th>Options</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    foreach ($users as $user):
                        ?>
                <tr>
                   <td><?= $user->users_id; ?></td>
                   <td><?= $user->last_name; ?></td>
                   <td><?= $user->first_name; ?></td>
                   <td><?= $user->middle_name; ?></td>
                   <td><?= $user->age; ?></td>
                   <td><?= $user->email ?></td>
                   <td><?= $user->department; ?></td>
                   <td><a href="">Edit</a> | <a href="">Delete</a></td>
                </tr>
                        <?php endforeach ?>
</tbody>
            </table>
        </div>
    </div>

    
</body>
</html>