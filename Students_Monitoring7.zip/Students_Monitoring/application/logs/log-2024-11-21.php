<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-11-21 01:49:27 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/URI.php 102
ERROR - 2024-11-21 01:49:27 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Router.php 128
ERROR - 2024-11-21 01:49:27 --> Severity: 8192 --> Creation of dynamic property Dashboard::$benchmark is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:49:27 --> Severity: 8192 --> Creation of dynamic property Dashboard::$hooks is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:49:27 --> Severity: 8192 --> Creation of dynamic property Dashboard::$config is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:49:27 --> Severity: 8192 --> Creation of dynamic property Dashboard::$log is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:49:27 --> Severity: 8192 --> Creation of dynamic property Dashboard::$utf8 is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:49:27 --> Severity: 8192 --> Creation of dynamic property Dashboard::$uri is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:49:27 --> Severity: 8192 --> Creation of dynamic property Dashboard::$exceptions is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:49:27 --> Severity: 8192 --> Creation of dynamic property Dashboard::$router is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:49:27 --> Severity: 8192 --> Creation of dynamic property Dashboard::$output is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:49:27 --> Severity: 8192 --> Creation of dynamic property Dashboard::$security is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:49:27 --> Severity: 8192 --> Creation of dynamic property Dashboard::$input is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:49:27 --> Severity: 8192 --> Creation of dynamic property Dashboard::$lang is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:49:27 --> Severity: 8192 --> Creation of dynamic property Dashboard::$db is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 397
ERROR - 2024-11-21 01:49:27 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/database/DB_driver.php 372
ERROR - 2024-11-21 01:49:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 303
ERROR - 2024-11-21 01:49:27 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 328
ERROR - 2024-11-21 01:49:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 355
ERROR - 2024-11-21 01:49:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 365
ERROR - 2024-11-21 01:49:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 366
ERROR - 2024-11-21 01:49:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 367
ERROR - 2024-11-21 01:49:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 368
ERROR - 2024-11-21 01:49:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 426
ERROR - 2024-11-21 01:49:27 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 110
ERROR - 2024-11-21 01:49:27 --> Severity: Warning --> session_start(): Session cannot be started after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 137
ERROR - 2024-11-21 01:49:27 --> Severity: 8192 --> Creation of dynamic property Dashboard::$session is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 1284
ERROR - 2024-11-21 01:49:27 --> Severity: 8192 --> Creation of dynamic property Dashboard::$form_validation is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 1284
ERROR - 2024-11-21 01:49:27 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$load is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:49:27 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$benchmark is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:49:27 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$hooks is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:49:27 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$config is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:49:27 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$log is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:49:27 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$utf8 is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:49:27 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$uri is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:49:27 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$exceptions is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:49:27 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$router is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:49:27 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$output is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:49:27 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$security is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:49:27 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$input is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:49:27 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$lang is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:49:27 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$db is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:49:27 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$session is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:49:27 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$form_validation is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:49:37 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/URI.php 102
ERROR - 2024-11-21 01:49:37 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Router.php 128
ERROR - 2024-11-21 01:49:37 --> Severity: 8192 --> Creation of dynamic property Login::$benchmark is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:49:37 --> Severity: 8192 --> Creation of dynamic property Login::$hooks is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:49:37 --> Severity: 8192 --> Creation of dynamic property Login::$config is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:49:37 --> Severity: 8192 --> Creation of dynamic property Login::$log is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:49:37 --> Severity: 8192 --> Creation of dynamic property Login::$utf8 is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:49:37 --> Severity: 8192 --> Creation of dynamic property Login::$uri is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:49:37 --> Severity: 8192 --> Creation of dynamic property Login::$exceptions is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:49:37 --> Severity: 8192 --> Creation of dynamic property Login::$router is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:49:37 --> Severity: 8192 --> Creation of dynamic property Login::$output is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:49:37 --> Severity: 8192 --> Creation of dynamic property Login::$security is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:49:37 --> Severity: 8192 --> Creation of dynamic property Login::$input is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:49:37 --> Severity: 8192 --> Creation of dynamic property Login::$lang is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:49:37 --> Severity: 8192 --> Creation of dynamic property Login::$db is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 397
ERROR - 2024-11-21 01:49:37 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/database/DB_driver.php 372
ERROR - 2024-11-21 01:49:37 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 303
ERROR - 2024-11-21 01:49:37 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 328
ERROR - 2024-11-21 01:49:37 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 355
ERROR - 2024-11-21 01:49:37 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 365
ERROR - 2024-11-21 01:49:37 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 366
ERROR - 2024-11-21 01:49:38 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 367
ERROR - 2024-11-21 01:49:38 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 368
ERROR - 2024-11-21 01:49:38 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 426
ERROR - 2024-11-21 01:49:38 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 110
ERROR - 2024-11-21 01:49:38 --> Severity: Warning --> session_start(): Session cannot be started after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 137
ERROR - 2024-11-21 01:49:38 --> Severity: 8192 --> Creation of dynamic property Login::$session is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 1284
ERROR - 2024-11-21 01:49:38 --> Severity: 8192 --> Creation of dynamic property Login::$form_validation is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 1284
ERROR - 2024-11-21 01:49:38 --> Severity: error --> Exception: Unable to locate the model you have specified: Login_model /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 349
ERROR - 2024-11-21 01:49:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Exceptions.php:272) /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Common.php 571
ERROR - 2024-11-21 01:55:22 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/URI.php 102
ERROR - 2024-11-21 01:55:22 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Router.php 128
ERROR - 2024-11-21 01:55:22 --> Severity: 8192 --> Creation of dynamic property Login::$benchmark is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:55:22 --> Severity: 8192 --> Creation of dynamic property Login::$hooks is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:55:22 --> Severity: 8192 --> Creation of dynamic property Login::$config is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:55:22 --> Severity: 8192 --> Creation of dynamic property Login::$log is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:55:22 --> Severity: 8192 --> Creation of dynamic property Login::$utf8 is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:55:22 --> Severity: 8192 --> Creation of dynamic property Login::$uri is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:55:22 --> Severity: 8192 --> Creation of dynamic property Login::$exceptions is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:55:22 --> Severity: 8192 --> Creation of dynamic property Login::$router is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:55:22 --> Severity: 8192 --> Creation of dynamic property Login::$output is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:55:22 --> Severity: 8192 --> Creation of dynamic property Login::$security is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:55:22 --> Severity: 8192 --> Creation of dynamic property Login::$input is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:55:22 --> Severity: 8192 --> Creation of dynamic property Login::$lang is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:55:22 --> Severity: 8192 --> Creation of dynamic property Login::$db is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 397
ERROR - 2024-11-21 01:55:22 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/database/DB_driver.php 372
ERROR - 2024-11-21 01:55:22 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 303
ERROR - 2024-11-21 01:55:22 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 328
ERROR - 2024-11-21 01:55:22 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 355
ERROR - 2024-11-21 01:55:22 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 365
ERROR - 2024-11-21 01:55:22 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 366
ERROR - 2024-11-21 01:55:22 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 367
ERROR - 2024-11-21 01:55:22 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 368
ERROR - 2024-11-21 01:55:22 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 426
ERROR - 2024-11-21 01:55:22 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 110
ERROR - 2024-11-21 01:55:22 --> Severity: Warning --> session_start(): Session cannot be started after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 137
ERROR - 2024-11-21 01:55:22 --> Severity: 8192 --> Creation of dynamic property Login::$session is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 1284
ERROR - 2024-11-21 01:55:22 --> Severity: 8192 --> Creation of dynamic property Login::$form_validation is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 1284
ERROR - 2024-11-21 01:55:22 --> Severity: 8192 --> Creation of dynamic property Login_model::$table is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/application/models/Login_model.php 8
ERROR - 2024-11-21 01:55:22 --> Severity: 8192 --> Creation of dynamic property Login::$Login_model is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 359
ERROR - 2024-11-21 01:55:22 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$load is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:55:22 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$benchmark is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:55:22 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$hooks is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:55:22 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$config is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:55:22 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$log is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:55:22 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$utf8 is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:55:22 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$uri is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:55:22 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$exceptions is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:55:22 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$router is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:55:22 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$output is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:55:22 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$security is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:55:22 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$input is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:55:22 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$lang is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:55:22 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$db is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:55:22 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$session is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:55:22 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$form_validation is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:55:22 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$Login_model is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:55:22 --> Severity: Warning --> Undefined variable $data /storage/emulated/0/MyWebsite/Students_Monitoring/application/controllers/Login.php 14
ERROR - 2024-11-21 01:56:07 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/URI.php 102
ERROR - 2024-11-21 01:56:07 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Router.php 128
ERROR - 2024-11-21 01:56:07 --> Severity: 8192 --> Creation of dynamic property Login::$benchmark is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:56:07 --> Severity: 8192 --> Creation of dynamic property Login::$hooks is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:56:07 --> Severity: 8192 --> Creation of dynamic property Login::$config is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:56:07 --> Severity: 8192 --> Creation of dynamic property Login::$log is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:56:07 --> Severity: 8192 --> Creation of dynamic property Login::$utf8 is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:56:07 --> Severity: 8192 --> Creation of dynamic property Login::$uri is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:56:07 --> Severity: 8192 --> Creation of dynamic property Login::$exceptions is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:56:07 --> Severity: 8192 --> Creation of dynamic property Login::$router is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:56:07 --> Severity: 8192 --> Creation of dynamic property Login::$output is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:56:07 --> Severity: 8192 --> Creation of dynamic property Login::$security is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:56:07 --> Severity: 8192 --> Creation of dynamic property Login::$input is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:56:07 --> Severity: 8192 --> Creation of dynamic property Login::$lang is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:56:07 --> Severity: 8192 --> Creation of dynamic property Login::$db is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 397
ERROR - 2024-11-21 01:56:07 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/database/DB_driver.php 372
ERROR - 2024-11-21 01:56:07 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 303
ERROR - 2024-11-21 01:56:07 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 328
ERROR - 2024-11-21 01:56:07 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 355
ERROR - 2024-11-21 01:56:07 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 365
ERROR - 2024-11-21 01:56:07 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 366
ERROR - 2024-11-21 01:56:07 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 367
ERROR - 2024-11-21 01:56:07 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 368
ERROR - 2024-11-21 01:56:07 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 426
ERROR - 2024-11-21 01:56:07 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 110
ERROR - 2024-11-21 01:56:07 --> Severity: Warning --> session_start(): Session cannot be started after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 137
ERROR - 2024-11-21 01:56:07 --> Severity: 8192 --> Creation of dynamic property Login::$session is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 1284
ERROR - 2024-11-21 01:56:07 --> Severity: 8192 --> Creation of dynamic property Login::$form_validation is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 1284
ERROR - 2024-11-21 01:56:07 --> Severity: 8192 --> Creation of dynamic property Login_model::$table is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/application/models/Login_model.php 8
ERROR - 2024-11-21 01:56:07 --> Severity: 8192 --> Creation of dynamic property Login::$Login_model is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 359
ERROR - 2024-11-21 01:56:07 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$load is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:56:07 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$benchmark is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:56:07 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$hooks is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:56:07 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$config is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:56:07 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$log is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:56:07 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$utf8 is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:56:07 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$uri is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:56:07 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$exceptions is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:56:07 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$router is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:56:07 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$output is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:56:07 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$security is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:56:07 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$input is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:56:07 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$lang is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:56:07 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$db is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:56:07 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$session is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:56:07 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$form_validation is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:56:07 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$Login_model is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:56:07 --> Severity: Warning --> Undefined variable $where /storage/emulated/0/MyWebsite/Students_Monitoring/application/controllers/Login.php 14
ERROR - 2024-11-21 01:56:19 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/URI.php 102
ERROR - 2024-11-21 01:56:19 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Router.php 128
ERROR - 2024-11-21 01:56:19 --> Severity: 8192 --> Creation of dynamic property Login::$benchmark is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:56:19 --> Severity: 8192 --> Creation of dynamic property Login::$hooks is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:56:19 --> Severity: 8192 --> Creation of dynamic property Login::$config is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:56:19 --> Severity: 8192 --> Creation of dynamic property Login::$log is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:56:19 --> Severity: 8192 --> Creation of dynamic property Login::$utf8 is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:56:19 --> Severity: 8192 --> Creation of dynamic property Login::$uri is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:56:19 --> Severity: 8192 --> Creation of dynamic property Login::$exceptions is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:56:19 --> Severity: 8192 --> Creation of dynamic property Login::$router is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:56:19 --> Severity: 8192 --> Creation of dynamic property Login::$output is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:56:19 --> Severity: 8192 --> Creation of dynamic property Login::$security is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:56:19 --> Severity: 8192 --> Creation of dynamic property Login::$input is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:56:19 --> Severity: 8192 --> Creation of dynamic property Login::$lang is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:56:19 --> Severity: 8192 --> Creation of dynamic property Login::$db is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 397
ERROR - 2024-11-21 01:56:19 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/database/DB_driver.php 372
ERROR - 2024-11-21 01:56:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 303
ERROR - 2024-11-21 01:56:19 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 328
ERROR - 2024-11-21 01:56:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 355
ERROR - 2024-11-21 01:56:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 365
ERROR - 2024-11-21 01:56:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 366
ERROR - 2024-11-21 01:56:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 367
ERROR - 2024-11-21 01:56:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 368
ERROR - 2024-11-21 01:56:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 426
ERROR - 2024-11-21 01:56:19 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 110
ERROR - 2024-11-21 01:56:19 --> Severity: Warning --> session_start(): Session cannot be started after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 137
ERROR - 2024-11-21 01:56:19 --> Severity: 8192 --> Creation of dynamic property Login::$session is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 1284
ERROR - 2024-11-21 01:56:19 --> Severity: 8192 --> Creation of dynamic property Login::$form_validation is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 1284
ERROR - 2024-11-21 01:56:19 --> Severity: 8192 --> Creation of dynamic property Login_model::$table is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/application/models/Login_model.php 8
ERROR - 2024-11-21 01:56:19 --> Severity: 8192 --> Creation of dynamic property Login::$Login_model is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 359
ERROR - 2024-11-21 01:56:19 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$load is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:56:19 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$benchmark is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:56:19 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$hooks is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:56:19 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$config is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:56:19 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$log is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:56:19 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$utf8 is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:56:19 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$uri is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:56:19 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$exceptions is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:56:19 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$router is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:56:19 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$output is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:56:19 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$security is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:56:19 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$input is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:56:19 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$lang is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:56:19 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$db is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:56:19 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$session is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:56:19 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$form_validation is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:56:19 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$Login_model is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:56:21 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/URI.php 102
ERROR - 2024-11-21 01:56:21 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Router.php 128
ERROR - 2024-11-21 01:56:21 --> Severity: 8192 --> Creation of dynamic property Login::$benchmark is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:56:21 --> Severity: 8192 --> Creation of dynamic property Login::$hooks is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:56:21 --> Severity: 8192 --> Creation of dynamic property Login::$config is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:56:21 --> Severity: 8192 --> Creation of dynamic property Login::$log is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:56:21 --> Severity: 8192 --> Creation of dynamic property Login::$utf8 is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:56:21 --> Severity: 8192 --> Creation of dynamic property Login::$uri is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:56:21 --> Severity: 8192 --> Creation of dynamic property Login::$exceptions is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:56:21 --> Severity: 8192 --> Creation of dynamic property Login::$router is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:56:21 --> Severity: 8192 --> Creation of dynamic property Login::$output is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:56:21 --> Severity: 8192 --> Creation of dynamic property Login::$security is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:56:21 --> Severity: 8192 --> Creation of dynamic property Login::$input is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:56:21 --> Severity: 8192 --> Creation of dynamic property Login::$lang is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:56:21 --> Severity: 8192 --> Creation of dynamic property Login::$db is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 397
ERROR - 2024-11-21 01:56:21 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/database/DB_driver.php 372
ERROR - 2024-11-21 01:56:21 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 303
ERROR - 2024-11-21 01:56:21 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 328
ERROR - 2024-11-21 01:56:21 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 355
ERROR - 2024-11-21 01:56:21 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 365
ERROR - 2024-11-21 01:56:21 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 366
ERROR - 2024-11-21 01:56:21 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 367
ERROR - 2024-11-21 01:56:21 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 368
ERROR - 2024-11-21 01:56:21 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 426
ERROR - 2024-11-21 01:56:21 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 110
ERROR - 2024-11-21 01:56:21 --> Severity: Warning --> session_start(): Session cannot be started after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 137
ERROR - 2024-11-21 01:56:21 --> Severity: 8192 --> Creation of dynamic property Login::$session is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 1284
ERROR - 2024-11-21 01:56:21 --> Severity: 8192 --> Creation of dynamic property Login::$form_validation is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 1284
ERROR - 2024-11-21 01:56:21 --> Severity: 8192 --> Creation of dynamic property Login_model::$table is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/application/models/Login_model.php 8
ERROR - 2024-11-21 01:56:21 --> Severity: 8192 --> Creation of dynamic property Login::$Login_model is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 359
ERROR - 2024-11-21 01:56:21 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$load is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:56:21 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$benchmark is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:56:21 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$hooks is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:56:21 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$config is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:56:21 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$log is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:56:21 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$utf8 is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:56:21 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$uri is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:56:21 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$exceptions is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:56:21 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$router is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:56:21 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$output is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:56:21 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$security is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:56:21 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$input is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:56:21 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$lang is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:56:21 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$db is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:56:21 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$session is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:56:21 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$form_validation is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:56:21 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$Login_model is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:57:16 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/URI.php 102
ERROR - 2024-11-21 01:57:16 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Router.php 128
ERROR - 2024-11-21 01:57:16 --> Severity: 8192 --> Creation of dynamic property Login::$benchmark is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:57:16 --> Severity: 8192 --> Creation of dynamic property Login::$hooks is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:57:16 --> Severity: 8192 --> Creation of dynamic property Login::$config is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:57:16 --> Severity: 8192 --> Creation of dynamic property Login::$log is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:57:16 --> Severity: 8192 --> Creation of dynamic property Login::$utf8 is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:57:16 --> Severity: 8192 --> Creation of dynamic property Login::$uri is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:57:16 --> Severity: 8192 --> Creation of dynamic property Login::$exceptions is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:57:16 --> Severity: 8192 --> Creation of dynamic property Login::$router is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:57:16 --> Severity: 8192 --> Creation of dynamic property Login::$output is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:57:16 --> Severity: 8192 --> Creation of dynamic property Login::$security is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:57:16 --> Severity: 8192 --> Creation of dynamic property Login::$input is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:57:16 --> Severity: 8192 --> Creation of dynamic property Login::$lang is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:57:16 --> Severity: 8192 --> Creation of dynamic property Login::$db is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 397
ERROR - 2024-11-21 01:57:16 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/database/DB_driver.php 372
ERROR - 2024-11-21 01:57:16 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 303
ERROR - 2024-11-21 01:57:16 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 328
ERROR - 2024-11-21 01:57:16 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 355
ERROR - 2024-11-21 01:57:16 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 365
ERROR - 2024-11-21 01:57:16 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 366
ERROR - 2024-11-21 01:57:16 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 367
ERROR - 2024-11-21 01:57:16 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 368
ERROR - 2024-11-21 01:57:16 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 426
ERROR - 2024-11-21 01:57:16 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 110
ERROR - 2024-11-21 01:57:16 --> Severity: Warning --> session_start(): Session cannot be started after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 137
ERROR - 2024-11-21 01:57:16 --> Severity: 8192 --> Creation of dynamic property Login::$session is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 1284
ERROR - 2024-11-21 01:57:16 --> Severity: 8192 --> Creation of dynamic property Login::$form_validation is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 1284
ERROR - 2024-11-21 01:57:16 --> Severity: 8192 --> Creation of dynamic property Login_model::$table is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/application/models/Login_model.php 8
ERROR - 2024-11-21 01:57:16 --> Severity: 8192 --> Creation of dynamic property Login::$Login_model is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 359
ERROR - 2024-11-21 01:57:16 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$load is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:57:16 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$benchmark is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:57:16 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$hooks is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:57:16 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$config is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:57:16 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$log is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:57:16 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$utf8 is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:57:16 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$uri is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:57:16 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$exceptions is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:57:16 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$router is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:57:16 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$output is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:57:16 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$security is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:57:16 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$input is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:57:16 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$lang is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:57:16 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$db is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:57:16 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$session is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:57:16 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$form_validation is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:57:16 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$Login_model is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:57:39 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/URI.php 102
ERROR - 2024-11-21 01:57:39 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Router.php 128
ERROR - 2024-11-21 01:57:39 --> Severity: 8192 --> Creation of dynamic property Login::$benchmark is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:57:39 --> Severity: 8192 --> Creation of dynamic property Login::$hooks is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:57:39 --> Severity: 8192 --> Creation of dynamic property Login::$config is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:57:39 --> Severity: 8192 --> Creation of dynamic property Login::$log is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:57:39 --> Severity: 8192 --> Creation of dynamic property Login::$utf8 is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:57:39 --> Severity: 8192 --> Creation of dynamic property Login::$uri is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:57:39 --> Severity: 8192 --> Creation of dynamic property Login::$exceptions is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:57:39 --> Severity: 8192 --> Creation of dynamic property Login::$router is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:57:39 --> Severity: 8192 --> Creation of dynamic property Login::$output is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:57:39 --> Severity: 8192 --> Creation of dynamic property Login::$security is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:57:39 --> Severity: 8192 --> Creation of dynamic property Login::$input is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:57:39 --> Severity: 8192 --> Creation of dynamic property Login::$lang is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:57:39 --> Severity: 8192 --> Creation of dynamic property Login::$db is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 397
ERROR - 2024-11-21 01:57:39 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/database/DB_driver.php 372
ERROR - 2024-11-21 01:57:39 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 303
ERROR - 2024-11-21 01:57:39 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 328
ERROR - 2024-11-21 01:57:39 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 355
ERROR - 2024-11-21 01:57:39 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 365
ERROR - 2024-11-21 01:57:39 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 366
ERROR - 2024-11-21 01:57:39 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 367
ERROR - 2024-11-21 01:57:39 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 368
ERROR - 2024-11-21 01:57:39 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 426
ERROR - 2024-11-21 01:57:39 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 110
ERROR - 2024-11-21 01:57:39 --> Severity: Warning --> session_start(): Session cannot be started after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 137
ERROR - 2024-11-21 01:57:39 --> Severity: 8192 --> Creation of dynamic property Login::$session is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 1284
ERROR - 2024-11-21 01:57:39 --> Severity: 8192 --> Creation of dynamic property Login::$form_validation is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 1284
ERROR - 2024-11-21 01:57:39 --> Severity: 8192 --> Creation of dynamic property Login_model::$table is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/application/models/Login_model.php 8
ERROR - 2024-11-21 01:57:39 --> Severity: 8192 --> Creation of dynamic property Login::$Login_model is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 359
ERROR - 2024-11-21 01:57:39 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$load is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:57:39 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$benchmark is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:57:39 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$hooks is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:57:39 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$config is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:57:39 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$log is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:57:39 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$utf8 is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:57:39 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$uri is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:57:39 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$exceptions is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:57:39 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$router is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:57:39 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$output is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:57:39 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$security is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:57:39 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$input is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:57:39 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$lang is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:57:39 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$db is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:57:39 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$session is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:57:39 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$form_validation is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:57:39 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$Login_model is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:57:55 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/URI.php 102
ERROR - 2024-11-21 01:57:55 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Router.php 128
ERROR - 2024-11-21 01:57:55 --> Severity: 8192 --> Creation of dynamic property Login::$benchmark is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:57:55 --> Severity: 8192 --> Creation of dynamic property Login::$hooks is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:57:55 --> Severity: 8192 --> Creation of dynamic property Login::$config is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:57:55 --> Severity: 8192 --> Creation of dynamic property Login::$log is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:57:55 --> Severity: 8192 --> Creation of dynamic property Login::$utf8 is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:57:55 --> Severity: 8192 --> Creation of dynamic property Login::$uri is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:57:55 --> Severity: 8192 --> Creation of dynamic property Login::$exceptions is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:57:55 --> Severity: 8192 --> Creation of dynamic property Login::$router is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:57:55 --> Severity: 8192 --> Creation of dynamic property Login::$output is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:57:55 --> Severity: 8192 --> Creation of dynamic property Login::$security is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:57:55 --> Severity: 8192 --> Creation of dynamic property Login::$input is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:57:55 --> Severity: 8192 --> Creation of dynamic property Login::$lang is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 01:57:55 --> Severity: 8192 --> Creation of dynamic property Login::$db is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 397
ERROR - 2024-11-21 01:57:55 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/database/DB_driver.php 372
ERROR - 2024-11-21 01:57:55 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 303
ERROR - 2024-11-21 01:57:55 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 328
ERROR - 2024-11-21 01:57:55 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 355
ERROR - 2024-11-21 01:57:55 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 365
ERROR - 2024-11-21 01:57:55 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 366
ERROR - 2024-11-21 01:57:55 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 367
ERROR - 2024-11-21 01:57:55 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 368
ERROR - 2024-11-21 01:57:55 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 426
ERROR - 2024-11-21 01:57:55 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 110
ERROR - 2024-11-21 01:57:55 --> Severity: Warning --> session_start(): Session cannot be started after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 137
ERROR - 2024-11-21 01:57:55 --> Severity: 8192 --> Creation of dynamic property Login::$session is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 1284
ERROR - 2024-11-21 01:57:55 --> Severity: 8192 --> Creation of dynamic property Login::$form_validation is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 1284
ERROR - 2024-11-21 01:57:55 --> Severity: 8192 --> Creation of dynamic property Login_model::$table is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/application/models/Login_model.php 8
ERROR - 2024-11-21 01:57:55 --> Severity: 8192 --> Creation of dynamic property Login::$Login_model is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 359
ERROR - 2024-11-21 01:57:55 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$load is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:57:55 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$benchmark is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:57:55 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$hooks is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:57:55 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$config is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:57:55 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$log is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:57:55 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$utf8 is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:57:55 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$uri is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:57:55 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$exceptions is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:57:55 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$router is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:57:55 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$output is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:57:55 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$security is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:57:55 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$input is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:57:55 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$lang is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:57:55 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$db is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:57:55 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$session is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:57:55 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$form_validation is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:57:55 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$Login_model is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 01:57:55 --> Severity: Warning --> Undefined variable $data /storage/emulated/0/MyWebsite/Students_Monitoring/application/controllers/Login.php 14
ERROR - 2024-11-21 02:11:13 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/URI.php 102
ERROR - 2024-11-21 02:11:13 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Router.php 128
ERROR - 2024-11-21 02:11:13 --> Severity: 8192 --> Creation of dynamic property Login::$benchmark is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 02:11:13 --> Severity: 8192 --> Creation of dynamic property Login::$hooks is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 02:11:13 --> Severity: 8192 --> Creation of dynamic property Login::$config is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 02:11:13 --> Severity: 8192 --> Creation of dynamic property Login::$log is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 02:11:13 --> Severity: 8192 --> Creation of dynamic property Login::$utf8 is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 02:11:13 --> Severity: 8192 --> Creation of dynamic property Login::$uri is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 02:11:13 --> Severity: 8192 --> Creation of dynamic property Login::$exceptions is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 02:11:13 --> Severity: 8192 --> Creation of dynamic property Login::$router is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 02:11:13 --> Severity: 8192 --> Creation of dynamic property Login::$output is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 02:11:13 --> Severity: 8192 --> Creation of dynamic property Login::$security is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 02:11:13 --> Severity: 8192 --> Creation of dynamic property Login::$input is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 02:11:13 --> Severity: 8192 --> Creation of dynamic property Login::$lang is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 02:11:13 --> Severity: 8192 --> Creation of dynamic property Login::$db is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 397
ERROR - 2024-11-21 02:11:13 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/database/DB_driver.php 372
ERROR - 2024-11-21 02:11:13 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 303
ERROR - 2024-11-21 02:11:13 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 328
ERROR - 2024-11-21 02:11:13 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 355
ERROR - 2024-11-21 02:11:13 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 365
ERROR - 2024-11-21 02:11:13 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 366
ERROR - 2024-11-21 02:11:13 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 367
ERROR - 2024-11-21 02:11:13 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 368
ERROR - 2024-11-21 02:11:13 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 426
ERROR - 2024-11-21 02:11:13 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 110
ERROR - 2024-11-21 02:11:13 --> Severity: Warning --> session_start(): Session cannot be started after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 137
ERROR - 2024-11-21 02:11:13 --> Severity: 8192 --> Creation of dynamic property Login::$session is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 1284
ERROR - 2024-11-21 02:11:13 --> Severity: 8192 --> Creation of dynamic property Login::$form_validation is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 1284
ERROR - 2024-11-21 02:11:13 --> Severity: 8192 --> Creation of dynamic property Login_model::$table is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/application/models/Login_model.php 8
ERROR - 2024-11-21 02:11:13 --> Severity: 8192 --> Creation of dynamic property Login::$Login_model is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 359
ERROR - 2024-11-21 02:11:13 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$load is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 02:11:13 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$benchmark is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 02:11:13 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$hooks is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 02:11:13 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$config is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 02:11:13 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$log is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 02:11:13 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$utf8 is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 02:11:13 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$uri is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 02:11:13 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$exceptions is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 02:11:13 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$router is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 02:11:13 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$output is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 02:11:13 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$security is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 02:11:13 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$input is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 02:11:13 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$lang is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 02:11:13 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$db is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 02:11:13 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$session is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 02:11:13 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$form_validation is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 02:11:13 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$Login_model is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 02:12:14 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/URI.php 102
ERROR - 2024-11-21 02:12:14 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Router.php 128
ERROR - 2024-11-21 02:12:14 --> Severity: 8192 --> Creation of dynamic property Login::$benchmark is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 02:12:14 --> Severity: 8192 --> Creation of dynamic property Login::$hooks is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 02:12:14 --> Severity: 8192 --> Creation of dynamic property Login::$config is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 02:12:14 --> Severity: 8192 --> Creation of dynamic property Login::$log is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 02:12:14 --> Severity: 8192 --> Creation of dynamic property Login::$utf8 is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 02:12:14 --> Severity: 8192 --> Creation of dynamic property Login::$uri is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 02:12:14 --> Severity: 8192 --> Creation of dynamic property Login::$exceptions is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 02:12:14 --> Severity: 8192 --> Creation of dynamic property Login::$router is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 02:12:14 --> Severity: 8192 --> Creation of dynamic property Login::$output is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 02:12:14 --> Severity: 8192 --> Creation of dynamic property Login::$security is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 02:12:14 --> Severity: 8192 --> Creation of dynamic property Login::$input is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 02:12:14 --> Severity: 8192 --> Creation of dynamic property Login::$lang is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Controller.php 83
ERROR - 2024-11-21 02:12:14 --> Severity: 8192 --> Creation of dynamic property Login::$db is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 397
ERROR - 2024-11-21 02:12:14 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/database/DB_driver.php 372
ERROR - 2024-11-21 02:12:14 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 303
ERROR - 2024-11-21 02:12:14 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 328
ERROR - 2024-11-21 02:12:14 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 355
ERROR - 2024-11-21 02:12:14 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 365
ERROR - 2024-11-21 02:12:14 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 366
ERROR - 2024-11-21 02:12:14 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 367
ERROR - 2024-11-21 02:12:14 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 368
ERROR - 2024-11-21 02:12:14 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 426
ERROR - 2024-11-21 02:12:14 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 110
ERROR - 2024-11-21 02:12:14 --> Severity: Warning --> session_start(): Session cannot be started after headers have already been sent /storage/emulated/0/MyWebsite/Students_Monitoring/system/libraries/Session/Session.php 137
ERROR - 2024-11-21 02:12:14 --> Severity: 8192 --> Creation of dynamic property Login::$session is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 1284
ERROR - 2024-11-21 02:12:14 --> Severity: 8192 --> Creation of dynamic property Login::$form_validation is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 1284
ERROR - 2024-11-21 02:12:14 --> Severity: 8192 --> Creation of dynamic property Login_model::$table is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/application/models/Login_model.php 8
ERROR - 2024-11-21 02:12:14 --> Severity: 8192 --> Creation of dynamic property Login::$Login_model is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 359
ERROR - 2024-11-21 02:12:14 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$load is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 02:12:14 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$benchmark is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 02:12:14 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$hooks is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 02:12:14 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$config is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 02:12:14 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$log is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 02:12:14 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$utf8 is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 02:12:14 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$uri is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 02:12:14 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$exceptions is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 02:12:14 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$router is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 02:12:14 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$output is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 02:12:14 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$security is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 02:12:14 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$input is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 02:12:14 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$lang is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 02:12:14 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$db is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 02:12:14 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$session is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 02:12:14 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$form_validation is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
ERROR - 2024-11-21 02:12:14 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$Login_model is deprecated /storage/emulated/0/MyWebsite/Students_Monitoring/system/core/Loader.php 932
