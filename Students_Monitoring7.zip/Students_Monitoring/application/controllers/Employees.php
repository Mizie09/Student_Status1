<?php

class Employees extends CI_Controller
{
  public function __construct()
    {
        parent::__construct();
        
        $this->load->model('Users_model');
    }
    public function index()
    {
        $data['users'] = $this->Users_model->rows();
        $this->load->view('templates/header');
        $this->load->view('employees/nav');
        $this->load->view('employees/index', $data);
        $this->load->view('templates/footer');
        
    }
    public function add()
    {
        $this->form_validation->set_rules('users_id','Employees No.','trim|required');
        $this->form_validation->set_rules('department','Department.','trim|required');
        $this->form_validation->set_rules('last_name', 'Last Name', 'trim|required');
        $this->form_validation->set_rules('first_name', 'First Name', 'trim|required');
        $this->form_validation->set_rules('middle_name', 'Middle Name', 'trim|required');
        $this->form_validation->set_rules('birthday', 'Birthday', 'trim|required');
        $this->form_validation->set_rules('age', 'Age', 'trim|required');
        $this->form_validation->set_rules('email', 'Email', 'trim|required');
        
        if ($this->form_validation->run())
            
        {
            $data = array(
            'users_id'   => $this->input->post('users_id'),
            'password'   => hash('sha256', 'abc567$^&'),
            'last_name'  => $this->input->post('last_name'),
            'first_name' => $this->input->post('first_name'),
            'middle_name'=> $this->input->post('middle_name'),
            'birthday'   => $this->input->post('birthday'),
            'age'        => $this->input->post('age'),
            'email'      => $this->input->post('email'),
            'department' => $this->input->post('department'),
            'created_by' => 'abc-0000-0001',
            'created_at' => date ('Y-m-d')
            );
         $result = $this->Users_model->add($data);
        
         if ($result) {
            $this->session->set_flashdata('msg', 'Succesfully');
            redirect('Employees');
         }
         else {
             $this->session->set_flashdata('errmsg', 'Failed');
            redirect('Employees/add');
         }
        }
         $this->load->view('templates/header');
        $this->load->view('templates/nav');
        $this->load->view('employees/add');
        $this->load->view('templates/footer');
    }
    public function update($id) 
    {
        $this->form_validation->set_rules('users_id','Employees No.','trim|required');
        $this->form_validation->set_rules('department','Department.','trim|required');
        $this->form_validation->set_rules('last_name', 'Last Name', 'trim|required');
        $this->form_validation->set_rules('first_name', 'First Name', 'trim|required');
        $this->form_validation->set_rules('middle_name', 'Middle Name', 'trim|required');
        $this->form_validation->set_rules('birthday', 'Birthday', 'trim|required');
        $this->form_validation->set_rules('age', 'Age', 'trim|required');
        $this->form_validation->set_rules('email', 'Email', 'trim|required');
        
        if ($this->form_validation->run())
            
        {
            $data = array(
            'users_id'   => $this->input->post('users_id'),
            'last_name'  => $this->input->post('last_name'),
            'first_name' => $this->input->post('first_name'),
            'middle_name'=> $this->input->post('middle_name'),
            'birthday'   => $this->input->post('birthday'),
            'age'        => $this->input->post('age'),
            'email'      => $this->input->post('email'),
            'department' => $this->input->post('department'),
            'edited_by' => 'abc-0000-0001',
            'edited_at' => date ('Y-m-d')
            );
         $result = $this->Users_model->update($id, $data);
        if ($result) {
            $this->session->set_flashdata('msg', 'Succesfully');
            redirect('Employees');
         }
         else {
             $this->session->set_flashdata('errmsg', 'Failed');
            redirect('Employees/update');
         }
    }
        $data['user'] = $this->Users_model->row($id);
        
        $this->load->view('templates/header');
        $this->load->view('templates/nav');
        $this->load->view('employees/edit', $data);
        $this->load->view('templates/footer');
    }
}