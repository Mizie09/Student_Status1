<?php

class Login extends CI_Controller
{
  public function __construct()
    {
        parent::__construct();
        
        $this->load->model('Login_model');
    }
    public function index()
    {
        $this->load->view('templates/header');
        $this->load->view('login/index');
        $this->load->view('templates/footer');
        
    }
    public function login()
    {
        $this->form_validation->set_rules('users_id','Employees No.','trim|required');
        $this->form_validation->set_rules('password','Password.','trim|required');
       
        if ($this->form_validation->run())
            
        {
            $data = array(
            'users_id'   => $this->input->post('users_id'),
            'password'   => hash('sha256', $this->input->post('password')),
            'is_deleted' => 0
            );
         $result = $this->Login_model->login($data);
        
         if ($result) {
           // $this->session->set_flashdata('msg', 'Succesfully');
            redirect('Dashboard');
         }
         else {
            // $this->session->set_flashdata('errmsg', 'Failed');
           // redirect('Login/login');
         }
        }
         $this->load->view('templates/header');
        $this->load->view('login/index');
        $this->load->view('templates/footer');
    }
    public function update($id) 
    {
        
    }
}