
    <div>
        <div>
            <h3>Employees</h3>
        </div>
        <div>
            <label>Search: 
            </label><input type="search" name="" id="">
            <a class="btn btn-primary" href="<?= site_url('Employees/add') ?>">Add</a>
        </div>
        <div>
            <?php
                if($this->session->flashdata('msg')){
                    echo $this->session->flashdata('msg');
                }

            ?>
            <table class="table">
<thead>
                <tr>
                    <th>Employee No.</th>
                    <th>Last Name</th>
                    <th>First Name</th>
                    <th>Middle Name</th>
                    <th>Age</th>
                    <th>Email</th>
                    <th>Department</th>
                    <th>Options</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    foreach ($users as $user):
                        ?>
                <tr>
                   <td><?= $user->users_id; ?></td>
                   <td><?= $user->last_name; ?></td>
                   <td><?= $user->first_name; ?></td>
                   <td><?= $user->middle_name; ?></td>
                   <td><?= $user->age; ?></td>
                   <td><?= $user->email ?></td>
                   <td><?= $user->department; ?></td>
                   <td><a class="btn btn-success" href="<?= site_url('Employees/update/'.$user->id ) ?>">Edit</a> | <a class="btn btn-danger" href="">Delete</a></td>
                </tr>
                        <?php endforeach ?>
</tbody>
            </table>
        </div>
    </div>