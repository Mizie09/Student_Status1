</div>
    <script src="<?= base_url('assets/js/jquery.js')?>"></script>
<script src="<?= base_url('assets/js/popper.js')?>"></script>
<script src="<?= base_url('assets/js/bootstrap.js')?>"></script>

</body>
</html>